CamingoCode v1.0

Copyright (c) 2006-2022 by Jan Fromm. All rights reserved.

This typeface is free for personal and commercial use. You are free to copy and transmit this typeface. You may not alter, transform, or build upon this typeface. Jan Fromm is not liable for any damage resulting from the use of this typeface.

This typeface is licensed under Creative Commons CC BY-ND, Version 3.0
http://creativecommons.org/licenses/by-nd/3.0/


January 2020
Jan Fromm Type & Graphic Design
Müggelseedamm 70
12587 Berlin
Germany

janfromm.de